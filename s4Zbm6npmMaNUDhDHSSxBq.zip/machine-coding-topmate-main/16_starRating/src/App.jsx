import StarRating from './components/StarRating';

const App = () => {
  return <StarRating />;
};

export default App;
