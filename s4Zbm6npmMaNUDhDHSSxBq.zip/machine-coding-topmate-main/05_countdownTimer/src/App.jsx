import Timer from './components/Timer'; // Adjust the path as necessary

function App() {
  return (
    <div className='App'>
      <Timer />
    </div>
  );
}

export default App;
