import React, { useState, useEffect } from 'react';
import CountriesPage from './CountriesPage';

function App() {
  return (
    <div className='App'>
      <CountriesPage />
    </div>
  );
}

export default App;
