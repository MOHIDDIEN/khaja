import React from 'react';
import Tabs from './components/Tabs';

const App = () => {
  return <Tabs />;
};

export default App;
