import './App.css';
import Progressbar from './components/ProgressBar';

function App() {
  return (
    <div className='App'>
      <Progressbar />
    </div>
  );
}

export default App;
