const CategoryFilter = ({ categories, onFilterChange }) => {
  return (
    <select onChange={(e) => onFilterChange(e.target.value)} defaultValue='All'>
      {categories.map((category) => (
        <option key={category} value={category}>
          {category}
        </option>
      ))}
    </select>
  );
};

export default CategoryFilter