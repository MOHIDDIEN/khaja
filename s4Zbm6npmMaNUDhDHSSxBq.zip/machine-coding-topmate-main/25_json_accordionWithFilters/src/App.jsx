// Make a fetch request to https://okrcentral.github.io/sample-okrs/db.json
// Any object without parent_object_id is an parent objective
// Any object with parent_objective_id is a Key Result (child_objective). So this has to be rendered below its parent objective in the hierarchy . 
// Parent_objective_id is the ID of the parent objective of a child objective

import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faUser,
  faChevronDown,
  faChevronRight,
} from '@fortawesome/free-solid-svg-icons';
import './App.css';
import CategoryFilter from './components/CategoryFilter';

function App() {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState('All');
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetch('https://okrcentral.github.io/sample-okrs/db.json')
      .then((response) => response.json())
      .then((json) => {
        const uniqueCategories = new Set(
          json.data.map((item) => item.category)
        );
        setCategories(['All', ...Array.from(uniqueCategories)]);
        setData(processData(json.data));
      });
  }, [filter]);

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
  };

  const processData = (data) => {
    let filteredData = data;
    if (filter !== 'All') {
      filteredData = data.filter((item) => item.category === filter);
    }
    const objectives = filteredData.filter(
      (item) => item.parent_objective_id === ''
    );
    objectives.forEach((obj) => {
      obj.keyResults = filteredData.filter(
        (item) => item.parent_objective_id === obj.id
      );
      obj.visible = true; // Keep previously set visibility or set default
    });
    return objectives;
  };

  const toggleVisibility = (id) => {
    const newData = data.map((obj) => {
      if (obj.id === id) {
        obj.visible = !obj.visible; // Toggle visibility
      }
      return obj;
    });
    setData(newData);
  };

  const renderObjective = (objective, index) => (
    <div key={index} className='objective-container'>
      <div className='objective-header'>
        <span
          className='toggle-icon'
          onClick={() => toggleVisibility(objective.id)}
        >
          {objective.visible ? (
            <FontAwesomeIcon icon={faChevronDown} />
          ) : (
            <FontAwesomeIcon icon={faChevronRight} />
          )}
        </span>
        <FontAwesomeIcon icon={faUser} className='user-icon' />
        <span className='objective-title'>
          {index + 1}. {objective.title}
        </span>
      </div>
      {objective.visible && (
        <div className='key-results'>
          {objective.keyResults.map((kr, krIndex) => (
            <div key={krIndex} className='key-result'>
              <FontAwesomeIcon icon={faUser} className='user-icon' />
              {String.fromCharCode(97 + krIndex)}. {kr.title}
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className='App'>
      <CategoryFilter
        categories={categories}
        onFilterChange={handleFilterChange}
      />
      {data.map(renderObjective)}
    </div>
  );
}

export default App;
