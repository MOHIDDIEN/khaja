import Typeahead from './TypeAhead';

export default function App() {
  return (
    <div className='wrapper'>
      <Typeahead />
    </div>
  );
}
