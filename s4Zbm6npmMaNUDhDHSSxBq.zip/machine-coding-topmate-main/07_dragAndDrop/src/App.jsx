import PuzzleGame from './components/PuzzleGame';
const App = () => {
  return (
    <div>
      <PuzzleGame />
    </div>
  );
};

export default App;
