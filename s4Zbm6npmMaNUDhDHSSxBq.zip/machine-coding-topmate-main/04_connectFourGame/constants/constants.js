export const size = 100;
export const rows = 6;
export const cols = 5;
