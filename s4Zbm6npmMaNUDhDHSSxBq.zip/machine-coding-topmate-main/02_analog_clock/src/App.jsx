import AnalogClock from "./components/AnalogClock"

const App = () => {
  return (
   <AnalogClock/>
  )
}

export default App