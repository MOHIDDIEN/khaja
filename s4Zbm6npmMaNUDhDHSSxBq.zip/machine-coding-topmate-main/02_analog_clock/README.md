![AnalogClock1](https://github.com/saiteja-gatadi1996/machineCoding_challenges/assets/42731246/443a5184-7b0c-4869-97d3-60cf5f8ce639)
