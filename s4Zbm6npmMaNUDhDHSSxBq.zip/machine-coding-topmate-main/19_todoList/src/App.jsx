import TodoList from './components/TodoList';

const App = () => {
  return <TodoList />;
};

export default App;
