import InfiniteScroll from './components/InfiniteScroll';

const App = () => {
  return <InfiniteScroll />;
};

export default App;
