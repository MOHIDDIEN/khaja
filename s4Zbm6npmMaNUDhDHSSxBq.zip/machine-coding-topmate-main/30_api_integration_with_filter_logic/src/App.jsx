import FilterList from "./components/FilterList"

const App = () => {
  return (
    <div>
      <FilterList/>
    </div>
  )
}
export default App