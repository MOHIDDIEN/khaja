![accordion12](https://github.com/saiteja-gatadi1996/machineCoding_challenges/assets/42731246/b1fef030-9ed7-4924-9906-66416a7990d2)
