export const data = [
  { id: 1, name: 'Apple', checked: false },
  { id: 2, name: 'Strawberry', checked: false },
  { id: 3, name: 'Pineapple', checked: false },
  { id: 4, name: 'Blueberry', checked: false },
  { id: 5, name: 'Mango', checked: false },
  { id: 6, name: 'Chocolate', checked: false },
];
