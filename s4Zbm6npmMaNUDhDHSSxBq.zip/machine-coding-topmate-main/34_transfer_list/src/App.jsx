import TransferList from './TransferList';
import './App.css'

const App = () => {
  return (
    <div className='App'>
      <TransferList />
    </div>
  );
};

export default App;
