![counter](https://github.com/saiteja-gatadi1996/machineCoding_challenges/assets/42731246/01caec7d-1708-4596-98be-fb7784715991)
