import CShapeBox from './components/CShapeBox';

const App = () => {
  return (
    <div>
      <CShapeBox />
    </div>
  );
};
export default App;
