import ToastNotification from './components/ToastNotification';

const App = () => {
  return <ToastNotification />;
};

export default App;
