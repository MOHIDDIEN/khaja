import EmailTemplates from './components/EmailTemplates';

const App = () => {
  return <EmailTemplates />;
};

export default App;
